package I3.Classes;

import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author Mutasim Alashoush
 */
public class Reservation {
    
   // int CONFIRMED = 0;
   // int RESERVED = 1;   
    
    // required Object
    
    private UserInfo customer;
    ArrayList<Room> rooms;
    
    
    
    private int Reservation_id;
    private long checkInDateTime;
    private long checkOutDateTime;
    private String ReservationType;
    private int person;
    //private int roomsFare;
    
    
    
    public Reservation()
    {
        customer = new UserInfo();
        rooms = new ArrayList<>();
        Reservation_id = -1;
        ReservationType = "Reserved";
        
    }

    public int getReservation_id() {
        return Reservation_id;
    }

    public void setReservation_id(int Reservation_id) {
        this.Reservation_id = Reservation_id;
    }

   
    
    public String getReservationType() {
        return ReservationType;
    }

    public void setReservationType(String ReservationType) {
        this.ReservationType = ReservationType;
    }
    
    
    
    
    public void addRoom(String roomNo)
    {
        rooms.add(new Room(roomNo));
        
    }
    
    public void removeRoom(String roomNo)
    {
        for(Room a: rooms)
        {
            if(a.getRoom_no().equals(roomNo))
            {
                rooms.remove(a);
            }
        }
    }

    public int getPerson() {
        return person;
    }

    public void setPerson(int person) {
        this.person = person;
    }

    public ArrayList<Room> getRooms() {
        return rooms;
    }
    
    public int getRoomsFare()
    {
        int total = 0;
        for(Room room:rooms)
        {
            total += room.getRoom_class().getPricePerDay();
        }
        return total;
    }

    public UserInfo getCustomer() {
        return customer;
    }

    public void setCustomer(UserInfo customer) {
        this.customer = customer;
    }

    

    public void setCheckOutDateTime(int checkOutDateTime) {
        this.checkOutDateTime = checkOutDateTime;
    }

    public long getCheckInDateTime() {
        return checkInDateTime;
    }

    public void setCheckInDateTime(long checkInDateTime) {
        this.checkInDateTime = checkInDateTime;
    }

    public long getCheckOutDateTime() {
        return checkOutDateTime;
    }

    public void setCheckOutDateTime(long checkOutDateTime) {
        this.checkOutDateTime = checkOutDateTime;
    }

 
    
    
    
            
    
}
